import os

cwd = os.getcwd()

print "Working directory: " + cwd