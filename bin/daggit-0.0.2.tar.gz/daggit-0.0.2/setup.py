#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'daggit',
        version = '0.0.2',
        description = '',
        long_description = '',
        author = '',
        author_email = '',
        license = 'MIT License',
        url = '',
        scripts = ['scripts/daggit'],
        packages = [
            'daggit',
            'daggit.core',
            'daggit.oplib',
            'daggit.runtime',
            'daggit.iolib',
            'daggit.oplib.core'
        ],
        namespace_packages = [],
        py_modules = ['__init__'],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            'airflow==1.8.0',
            'tables',
            'h5py',
            'pyyaml',
            'boto',
            'sklearn',
            'pandas',
            'numpy',
            'pint',
            'scipy',
            'six',
            'xgboost',
            'sphinx',
            'tox',
            'keras',
            'tensorflow'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
