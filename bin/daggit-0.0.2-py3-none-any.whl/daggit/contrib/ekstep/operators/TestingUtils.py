import io
import requests
import os
import logging
import difflib

#change if it doesnt work
logging.getLogger("requests").setLevel(logging.WARNING) 

import signal
import re
import sys
import json
import zipfile
import unicodedata
import time
import csv
import string
import shutil
import urllib
from urllib.parse import urlparse
import math
# import StringIO
import pickle
import youtube_dl

import mutagen.mp3 as mp3
import speech_recognition as sr
import pandas as pd
import numpy as np
import googleapiclient.discovery
import nltk
nltk.download("wordnet")
nltk.download("stopwords")
from nltk.corpus import stopwords
stopwords = stopwords.words('english')
import time


from google.cloud import translate
from google.cloud import vision
from pydub.playback import play
from PyPDF2 import PdfFileReader
#import Levenshtein
import plotly.plotly as py
import plotly.tools as tls
import plotly.graph_objs as go

from pydub import AudioSegment
from natsort import natsorted
from plotly import tools
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from collections import Counter
from nltk.stem import WordNetLemmatizer
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer



GOOGLE_APPLICATION_CREDENTIALS = r"""{
  "type": "service_account",
  "project_id": "machinelearningapi-175409",
  "private_key_id": "27cc5d0e439a6eeef7dd2a7c35c00d3dc4acd953",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCSFKC2+dMG6qhz\nx0smAFQGMXCWtiuti75G0Gurn3ciG/wEKsUWgd/dquFBJYB4ZOjOsyq0S03NRzFH\n/zwENFUlpitBMNbLoVCuL3x8rU5BKTN8xAu0RRsj/kmV/+zgiChVPgpstVQppNtf\nuc5+cPYJmUwrQ6t96zqhjppt0VhDiOtfIfCfXi5LK6Wj1T3i2AQL9Ekuaw1o2QDF\ncQ+EGb7yUkCy1MYGZ7KWtx7MhYIARL7/91Y1ry1mE00n48pmmMe6KPuC/Z0RY/X3\nrxFl6YScMm0AlP/r6gYmOHFI/d/SkJtDB4LWAmIiG80iK5X2pnErMt5ezyGqhFIk\nGhUizhFfAgMBAAECggEAAQbuXMeA4zNNFMVmNGJ0uljapCVTOilnimKHXeEbq1Lb\nC+MQDWvZvDkqC2ixZWoWef5DzJmWa5S387kz8SugJ7hkrUnK4Swpnlxs2aSaeCmZ\nNtB8fUauEQp1RJmthq9Px+THsD6We5hMs5oewBOeM8EpeZbVKyU3S1wE4cTIV5CC\ngmcwz3y+yttplREeAp7So9V0R5FpJ7P0qjal3Ngyu5aR6pgObNzhjXKeed6aULwc\neZIDlCwJhxetLqyhsGHHvFPQas6Y5mnET5mA4KRLV3u9KBh5KFc2f93nk7nqPeWz\nf0AQH9avBvTFT/RLBGRH4jNGaMovce0+AI9QLORzcQKBgQDEICcztYPIVjWvZ0Rs\ncBmhuy7yD1Rh7pZisC4A5iwoG7JH8sBXJm33bMWmRlztVDSLxi0GTS4ha7cGTSxG\nVJBKCUwVMWKDQQXQs9SKlUnTF94ozRzyozq9MSrJJcsXs9dE0++cTpT54eD6n8dU\nvLmPkrJ4j4u7SftgJQiQi9oUvQKBgQC+rUuQeinPpAXOKXsPPSOF/Z+kn8SS/kG8\nnkRqcsCnPOZxXUArBMmTahn/bUI6T+PzlXRbQSzEF3N1U++YquTqxACrwkiBv9Ak\ny7XugZzBcCmv4bDYgspOo0emKyl5uAvmQjceYgVANTsC5pD7hQERNGKvl8MA9VZn\nNlSA2iTWSwKBgQC/YRy/4Z0RzcYfPibPpeftIOnjfL/7vER1UrPhXrmx/azPdnrn\nz/E4oqSP51Ngp22LAzwGTSP5qtFzTbUpf/U4ua/LcmBN8hJJoGGDRcA/Q6geqmBY\nCJ4V5bd5hu6SV4R1flXvceL/n8HY7jclYe+0wRJ0gKZ6gOvR2vFrk3ygBQKBgBeg\nr8Fqce3p/FIsr7QWtmUvJW4n4hr46LpvvjiWmarfkAqyLHZoNHZQ6oHNTyyco7mW\nZoG8VMjDwynhycnYO1+gBBlEjOmPFELK/3NbmkoaFQBXbiuWIW2XLBS6Onx7wvW4\ndM4OBWqMbhCQ85xHQfeYzzXFD4P54sgNYnFJFtF7AoGAbMlWoReAAnjfB78chUZU\n8HWcSXi8ZLhR/uaZY7S3yJwA2Kz7Wa05WJ6hhT6MWHojClH36ZZb8jms/ddFKEuG\nTEaLGEL3eoniYtzg7wk34u9H6+0OBhXdYJbXcnapeUR4FYhOEw/9AA3dNhD2/ne+\npVGBX9PagFWhBI1TC75klnM=\n-----END PRIVATE KEY-----\n",
  "client_email": "machinelearningapi@machinelearningapi-175409.iam.gserviceaccount.com",
  "client_id": "107107468801573946683",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://accounts.google.com/o/oauth2/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/machinelearningapi%40machinelearningapi-175409.iam.gserviceaccount.com"
}"""

def content_meta_features_checking(df, mandatoy_fields):
  check = [0 if elem in list(df.columns) else 1 for elem in list(mandatoy_fields)]
  if sum(check) > 0:
    return True
  else:
    return False

def sentence_similarity(sentence1, sentence2, threshold):       # sentence simil
  sentence = difflib.SequenceMatcher(lambda x: x == " ",
                     sentence1, 
                     sentence2) 
  similarity_score = sentence.ratio()*100 
  if similarity_score >= threshold: 
    return 1
  else:
    return 0 

def text_Extraction(url, type_of_url, id_name, path_to_save, expected_text):  
    text_generated_path = content_to_text_conversion(url, type_of_url, id_name, path_to_save)
    actual_text = open(text_generated_path, "r") 
    actual_text = actual_text.read()
    if similarity(actual_text, expected_text, 0.40) == 1:
        return 1
    else:
        return 0 
 

def intersection_lists(list_1, list_2, threshold):
    if 1.0*(len(set(list_1) & set(list_2))/ min(len(set(list_1)),len(set(list_2)))) > threshold:
        return 1
    else:
        return 0 

def keyword_extraction( path_to_text, path_to_save_tagme, expected_output):
    file_ = open(path_to_text, "r")
    text = file_.readline()
    if text == '':
        return "Text is not available"
    
    if detect(text) != 'en':           
        return "Non English text"
    else: 
        path_to_tagme_output = get_tagme_longtext(path_to_text, path_to_save_tagme)    
        actual_output = pd.read_csv(path_to_tagme_output)
        actual_output = list(actual_output["KEYWORDS"])
        intersection_lists_output = intersection_lists(actual_output, expected_output,0.8)  
        return intersection_lists_output


def evaluation_comparison(content_keywords, taxonomy_keywords, evaluation_criteria, threshold):
    evaluation_score = jaccard_with_phrase(content_keywords, taxonomy_keywords)
    if evaluation_score[evaluation_criteria] > threshold:
        return 'keyword list Distance is less'           #### Jaacard value, 
    else:
        return 'keyword list Distance is more' 
