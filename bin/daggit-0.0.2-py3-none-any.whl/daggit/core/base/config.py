DAGGIT_HOME = "DAGGIT_HOME"
STORE = 'Local'
ORCHESTRATOR = 'airflow'
STORAGE_FORMAT = '.h5'
ORCHESTRATOR_AIRFLOW_dag_config_depends_on_past = False
ORCHESTRATOR_AIRFLOW_dag_config_schedule_interval = '@once'
ORCHESTRATOR_AIRFLOW_dag_config_start_date = '20-11-2018'
