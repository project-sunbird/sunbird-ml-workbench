import multiprocessing
import time
import os
import glob
import json
import requests
import logging
import pandas as pd
import numpy as np
import configparser
from functools import partial, reduce
from kafka import KafkaProducer, KafkaConsumer, KafkaClient

from daggit.core.io.io import Pandas_Dataframe, File_Txt
from daggit.core.io.io import ReadDaggitTask_Folderpath
from daggit.core.base.factory import BaseOperator
from ..operators.contentTaggingUtils import multimodal_text_enrichment
from ..operators.contentTaggingUtils import keyword_extraction_parallel
from ..operators.contentTaggingUtils import get_level_keywords
from ..operators.contentTaggingUtils import jaccard_with_phrase
from ..operators.contentTaggingUtils import save_obj, load_obj, findFiles
from ..operators.contentTaggingUtils import merge_json
from ..operators.contentTaggingUtils import strip_word, get_words
from ..operators.contentTaggingUtils import dictionary_merge, get_sorted_list
from ..operators.contentTaggingUtils import custom_listPreProc
from ..operators.contentTaggingUtils import df_feature_check, identify_contentType
from ..operators.contentTaggingUtils import precision_from_dictionary
from ..operators.contentTaggingUtils import agg_precision_from_dictionary
from ..operators.contentTaggingUtils import CustomDateFormater, findDate
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class ContentToTextRead(BaseOperator):

    @property
    def inputs(self):
        return {
                "pathTocredentials": ReadDaggitTask_Folderpath(self.node.inputs[0]),
                "localpathTocontentMeta": Pandas_Dataframe(self.node.inputs[1]),
                "folderTosave": ReadDaggitTask_Folderpath(self.node.inputs[2])
                }

    @property
    def outputs(self):
        return {"timestamp_folder": File_Txt(
                self.node.outputs[0])}

    def run(
            self,
            range_start,
            range_end,
            content_type):
        folderTosave = self.inputs["folderTosave"].read_loc()
        pathTocredentials = self.inputs["pathTocredentials"].read_loc()
        content_meta = self.inputs["localpathTocontentMeta"].read()
        if "derived_contentType" not in list(content_meta.columns):
            content_meta["derived_contentType"] = np.nan
            for row_ind, artifact_url in enumerate(content_meta["artifactUrl"]):
                try:
                    content_meta["derived_contentType"][row_ind] = identify_contentType(artifact_url)
                except BaseException:
                    pass
        content_meta = content_meta[pd.notnull(content_meta['derived_contentType'])]
        content_meta.reset_index(inplace=True, drop=True)
        print(self.outputs["timestamp_folder"].location_specify())
        oldwd = os.getcwd()
        contentMeta_mandatory_fields = [
            'artifactUrl',
            'derived_contentType',
            'downloadUrl',
            'gradeLevel',
            'identifier',
            'keywords',
            'language',
            'subject']
        assert df_feature_check(content_meta, contentMeta_mandatory_fields)
        timestr = time.strftime("%Y%m%d-%H%M%S")
        path_to_timestamp_folder = os.path.join(folderTosave, timestr)
        content_to_text_path = os.path.join(
            path_to_timestamp_folder, "content_to_text")
        # content dump:
        if not os.path.exists(content_to_text_path):
            os.makedirs(content_to_text_path)
            print("content_to_text: ", content_to_text_path)
        logging.info("CTT_CONTENT_TO_TEXT_START")
        # read content meta:
        if content_meta.columns[0] == "0":
            content_meta = content_meta.drop("0", axis=1)

        # check for duplicates in the meta
        if list(content_meta[content_meta.duplicated(
                ['artifactUrl'], keep=False)]["artifactUrl"]) != []:
            content_meta.drop_duplicates(subset="artifactUrl", inplace=True)
            content_meta.reset_index(drop=True, inplace=True)

        # dropna from artifactUrl feature and reset the index:
        content_meta.dropna(subset=["artifactUrl"], inplace=True)
        content_meta.reset_index(drop=True, inplace=True)

        # time the run
        start = time.time()
        logging.info(
            'Contents detected in the content meta: ' + str(len(content_meta)))
        logging.info(
            "----Running Content_to_Text for contents from {0} to {1}:".format(
                range_start, range_end))
        logging.info("time started: {0}".format(start))
        # subset contentMeta:
        # content_meta = content_meta[content_meta["derived_contentType"].isin(
        #     subset_contentMeta_by.split(", "))]
        # content_meta.reset_index(drop=True, inplace=True)
        if range_start == "START":
            range_start = 0
        if range_end == "END":
            range_end = len(content_meta)-1
        logging.info(
            "CTT_Config: content_meta from {0} to {1} created in: {2}".format(
                range_start, range_end, content_to_text_path))

        status = False
        if os.path.exists(pathTocredentials):
            try:
                config = configparser.ConfigParser(allow_no_value=True)
                config.read(pathTocredentials)
                status = True
                try:
                    path_to_googlecred = config['google application credentials']["GOOGLE_APPLICATION_CREDENTIALS"]
                    with open(path_to_googlecred, "r") as cred_json:
                        GOOGLE_APPLICATION_CREDENTIALS = cred_json.read()
                except BaseException:
                    logging.info("Invalid GOOGLE_APPLICATION_CREDENTIALS in config.")
                    logging.info("***Checking for GOOGLE_APPLICATION_CREDENTIALS environment variable")
                    status = False
            except BaseException:
                logging.info("Invalid config file")
                logging.info("***Checking for GOOGLE_APPLICATION_CREDENTIALS environment variable")

        if not status:
            try:
                GOOGLE_APPLICATION_CREDENTIALS = os.environ['GOOGLE_APPLICATION_CREDENTIALS']
                with open(GOOGLE_APPLICATION_CREDENTIALS, "r") as f:
                    GOOGLE_APPLICATION_CREDENTIALS = f.read()
            except BaseException:
                GOOGLE_APPLICATION_CREDENTIALS = ""
                logging.info("Not a valid google credential") 

        result = [
            multimodal_text_enrichment(
                i,
                timestr,
                content_meta,
                content_type,
                content_to_text_path,
                GOOGLE_APPLICATION_CREDENTIALS) for i in range(
                range_start,
                range_end,)]
        os.chdir(oldwd)
        print("Current directory for Auto_Tagging: ", os.getcwd())
        print("timestamp_folder path:", path_to_timestamp_folder)
        self.outputs["timestamp_folder"].write(path_to_timestamp_folder)


class KeywordExtraction(BaseOperator):

    @property
    def inputs(self):
        return {"pathTotaxonomy": Pandas_Dataframe(self.node.inputs[0]),
                "categoryLookup": ReadDaggitTask_Folderpath(self.node.inputs[1]),
                "timestamp_folder": File_Txt(self.node.inputs[2]),
                "pathTocorpus": ReadDaggitTask_Folderpath(self.node.inputs[3])
                }

    @property
    def outputs(self):
        return {"path_to_contentKeywords": File_Txt(self.node.outputs[0])
                }

    def run(self, extract_keywords, filter_criteria, update_corpus, filter_score_val, num_keywords):
        assert extract_keywords == "tagme" or extract_keywords == "text_token"
        assert filter_criteria == "none" or filter_criteria == "taxonomy" or filter_criteria == "dbpedia"
        taxonomy = self.inputs["pathTotaxonomy"].read()
        path_to_category_lookup = self.inputs["categoryLookup"].read_loc()
        path_to_corpus = self.inputs["pathTocorpus"].read_loc()
        timestamp_folder = self.inputs["timestamp_folder"].read()
        timestr = os.path.split(timestamp_folder)[1]
        print("****timestamp folder:", timestamp_folder)
        print("****categorylookup yaml:", path_to_category_lookup)
        content_to_text_path = os.path.join(timestamp_folder, "content_to_text")
        print("content_to_text path:", content_to_text_path)
        if not os.path.exists(content_to_text_path):
            logging.info("No such directory as: ", content_to_text_path)
        else:
            logging.info('------Transcripts to keywords extraction-----')
            pool = multiprocessing.Pool(processes=4)
            keywordExtraction_partial = partial(
               keyword_extraction_parallel,
               timestr=timestr,
               content_to_text_path=content_to_text_path,
               taxonomy=taxonomy,
               extract_keywords=extract_keywords,
               filter_criteria=filter_criteria,
               path_to_corpus=path_to_corpus,
               path_to_category_lookup=path_to_category_lookup,
               update_corpus=update_corpus,
               filter_score_val=filter_score_val,
               num_keywords=num_keywords)
            results = pool.map(
                keywordExtraction_partial, [
                    dir for dir in os.listdir(content_to_text_path)])
            print(results)
            print("path to content keywords:", max(glob.glob(
                os.path.join(timestamp_folder, 'content_to_text'))))
            c2t_path = os.path.join(timestamp_folder, 'content_to_text')
            self.outputs["path_to_contentKeywords"].write(max(glob.glob(
                c2t_path), key=os.path.getmtime))
            pool.close()
            pool.join()


class WriteToKafkaTopic(BaseOperator):

    @property
    def inputs(self):
        return {"path_to_contentKeywords": File_Txt(self.node.inputs[0])
                }

    def run(self, kafka_broker, kafkaTopic_writeTo):
        path_to_contentKeywords = self.inputs["path_to_contentKeywords"].read()
        timestamp_folder = os.path.split(os.path.split(timestamp_folder)[0])[1]
        timestr = os.path.split(timestamp_folder)[1]
        epoch_time = time.mktime(time.strptime(timestr, "%Y%m%d-%H%M%S"))
        content_to_textpath = os.path.join(timestamp_folder, "content_to_text")
        cid_name = [i for i in os.listdir(content_to_textpath) if i not in ['.DS_Store']]
        for cid in cid_name:
            merge_json_list = []
            json_file = findFiles(os.path.join(content_to_textpath, cid), ["json"])
            for file in json_file:
                if os.path.split(file)[1] in [
                        "ML_keyword_info.json", "ML_content_info.json"]:
                    merge_json_list.append(file)
            ignore_list = ["ets"]
            dict_list = []
            for file in merge_json_list:
                with open(file, "r", encoding="UTF-8") as info:
                    new_json = json.load(info)
                    [new_json.pop(ignore) for ignore in ignore_list if ignore in new_json.keys()]
                dict_list.append(new_json)
            # merge the nested jsons:-
            autotagging_json = reduce(merge, dict_list)
            autotagging_json.update({"ets": epoch_time})
            with open(os.path.join(timestamp_folder, "content_to_text", cid, "autoTagging_json.json"), "w+") as main_json:
                json.dump(autotagging_json, main_json, sort_keys=True, indent=4)
            client = KafkaClient(kafka_broker)
            server_topics = client.topic_partitions
            for i in server_topics:
                if i == kafkaTopic_writeTo:
                    producer = KafkaProducer(bootstrap_servers='localhost:9092', value_serializer=lambda v: json.dumps(v, indent=4).encode('utf-8'))
                    #serializing json message:-
                    event_send = producer.send(kafkaTopic_writeTo, autotagging_json)
                    result = event_send.get(timeout=60)