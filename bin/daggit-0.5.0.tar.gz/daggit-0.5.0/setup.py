#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'daggit',
        version = '0.5.0',
        description = '',
        long_description = '',
        author = '',
        author_email = '',
        license = 'MIT License',
        url = '',
        scripts = ['scripts/daggit'],
        packages = [
            'daggit',
            'daggit.core',
            'daggit.runtime',
            'daggit.contrib',
            'daggit.core.base',
            'daggit.core.nodes',
            'daggit.core.oplib',
            'daggit.core.io',
            'daggit.contrib.sunbird',
            'daggit.contrib.sunbird.nodes',
            'daggit.contrib.sunbird.oplib'
        ],
        namespace_packages = [],
        py_modules = ['__init__'],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            'apache-airflow==1.9.0',
            'pytest-runner',
            'dateutils',
            'h5py',
            'pyyaml',
            'boto',
            'sklearn',
            'pandas',
            'numpy',
            'pint',
            'scipy',
            'six',
            'xgboost',
            'sphinx',
            'tox',
            'networkx',
            'findspark',
            'gensim',
            'nltk',
            'grpcio',
            'grpcio-tools',
            'ffmpy',
            'ffmpeg-python',
            'youtube_dl',
            'google-cloud',
            'google-api-python-client',
            'oauth2client',
            'google',
            'google-cloud-translate',
            'google-cloud-vision',
            'pydub',
            'mutagen',
            'PyPDF2',
            'speechRecognition',
            'plotly',
            'natsort',
            'SPARQLWrapper',
            'elasticsearch',
            'pdfminer.six',
            'configparser==3.5.3',
            'sphinx_rtd_theme',
            'kafka',
            'pyspark',
            'redis'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
