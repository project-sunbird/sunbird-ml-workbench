#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'daggit',
        version = '0.5.0',
        description = '',
        long_description = '',
        author = '',
        author_email = '',
        license = 'MIT License',
        url = '',
        scripts = ['scripts/daggit'],
        packages = [
            'daggit',
            'daggit.core',
            'daggit.runtime',
            'daggit.contrib',
            'daggit.core.nodes',
            'daggit.core.oplib',
            'daggit.core.io',
            'daggit.core.base',
            'daggit.contrib.sunbird',
            'daggit.contrib.sunbird.nodes',
            'daggit.contrib.sunbird.oplib'
        ],
        namespace_packages = [],
        py_modules = ['__init__'],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            'apache-airflow==1.10.4',
            'pytest-runner==5.1',
            'dateutils==0.6.6',
            'h5py==2.9.0',
            'PyYAML==5.1.2',
            'boto==2.49.0',
            'boto3==1.9.130',
            'botocore==1.12.130',
            'scikit-learn==0.20.2',
            'pandas==0.25.1',
            'numpy==1.17.1',
            'Pint==0.9',
            'scipy==1.3.1',
            'six==1.12.0',
            'xgboost==0.90',
            'Sphinx==2.2.0',
            'tox==3.13.2',
            'networkx==2.3',
            'findspark==1.3.0',
            'gensim==3.8.0',
            'nltk==3.4.5',
            'grpcio==1.23.0',
            'grpcio-tools==1.23.0',
            'ffmpy==0.2.2',
            'ffmpeg-python==0.2.0',
            'youtube-dl==2019.8.13',
            'google-cloud==0.34.0',
            'google-cloud-core==1.0.3',
            'google-cloud-storage==1.19.0',
            'google-cloud-translate==1.6.0',
            'google-cloud-vision==0.39.0',
            'google-api-python-client==1.7.11',
            'oauth2client==4.1.3',
            'google==2.0.2',
            'pydub==0.23.1',
            'mutagen==1.42.0',
            'PyPDF2==1.26.0',
            'SpeechRecognition==3.8.1',
            'plotly==4.1.0',
            'natsort==6.0.0',
            'SPARQLWrapper==1.8.4',
            'elasticsearch==7.0.4',
            'pdfminer.six==20181108',
            'configparser==3.5.3',
            'sphinx-rtd-theme==0.4.3',
            'kafka==1.3.5',
            'pyspark==2.4.4',
            'redis==3.3.8',
            'mock==3.0.5',
            'ruptures==1.0.1',
            'biopython==1.74',
            'python-Levenshtein==0.12.0',
            'bert-serving-server==1.9.6',
            'bert-serving-client==1.9.6',
            'pyemd==0.5.1',
            'tensorflow==1.14.0',
            'gspread==3.1.0',
            'opencv-python==4.1.1.26',
            'spacy==2.1.8',
            'pdf2image==1.8.0',
            'Pillow==6.2.0',
            'img2pdf==0.3.3',
            'transformers==2.1.1',
            'tensorflow==1.14.0',
            'Keras==2.1.1',
            'sklearn==0.0',
            'torch==1.4.0',
            'werkzeug==0.16.0'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
